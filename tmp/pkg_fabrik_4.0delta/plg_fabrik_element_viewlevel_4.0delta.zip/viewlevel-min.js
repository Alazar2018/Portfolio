/*! Fabrik */

define(["jquery","fab/element"],function(e,i){return FbViewlevel=new Class({Extends:i,initialize:function(e,i){this.setPlugin("fabrikviewlevel"),this.parent(e,i)}}),window.FbViewlevel});