<?php

// No direct access
defined('_JEXEC') or die('Restricted access');

echo "<pre>";print_r($this->data);exit;echo "</pre>";