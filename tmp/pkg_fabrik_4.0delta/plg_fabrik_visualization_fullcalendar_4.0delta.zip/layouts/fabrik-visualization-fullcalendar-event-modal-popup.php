<?php
defined('JPATH_BASE') or die;

$d = $displayData;
?>
<div id="<?php echo $d->id; ?>" class="modal fade fabrikEventModal" role="dialog">
  <div class="modal-dialog modal-sm">
    <!-- Modal content-->
    <div class="modal-content" >
      <div class="modal-header">
        
        <h5 class="modal-title"><!-- Modal Header--></h5>
		<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <!-- modal body will go here -->
      </div>
      <div class="modal-footer">
        <div class="btn-group calEventButtons">
        </div>
      </div>
    </div>

  </div>
</div>
