/*! Fabrik */

define(["jquery","fab/element"],function(e,n){return window.FbFolder=new Class({Extends:n,initialize:function(e,n){this.setPlugin("fabrikfolder"),this.parent(e,n)}}),window.FbFolder});