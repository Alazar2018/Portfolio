<?php
defined('JPATH_BASE') or die;
$d = $displayData;
?>

<img src="<?php echo $d->link; ?>" width="<?php echo $d->digsig_width; ?>" height="<?php echo $d->digsig_height; ?>" />