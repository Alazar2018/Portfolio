<?php
defined('JPATH_BASE') or die;

$d = $displayData;
?>

<img src="<?php echo $d->src; ?>" width="<?php echo $d->width; ?>" height="<?php echo $d->height; ?>" />