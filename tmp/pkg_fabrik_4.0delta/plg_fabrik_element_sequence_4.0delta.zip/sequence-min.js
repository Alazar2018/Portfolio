/*! Fabrik */

define(["jquery","fab/element"],function(e,n){return window.FbSequence=new Class({Extends:n,initialize:function(e,n){this.setPlugin("FbSequence"),this.parent(e,n)}}),window.FbSequence});