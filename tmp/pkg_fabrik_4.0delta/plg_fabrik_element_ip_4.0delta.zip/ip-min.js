/*! Fabrik */

define(["jquery","fab/element"],function(n,e){return window.FbIp=new Class({Extends:e,initialize:function(n,e){this.setPlugin("FbIp"),this.parent(n,e)}}),window.FbIp});