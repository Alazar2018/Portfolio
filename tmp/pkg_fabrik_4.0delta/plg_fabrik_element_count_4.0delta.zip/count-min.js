/*! Fabrik */

define(["jquery","fab/element"],function(n,i){return window.FbCount=new Class({Extends:i,initialize:function(n,i){this.setPlugin("fabrikcount"),this.parent(n,i)}}),window.FbCount});