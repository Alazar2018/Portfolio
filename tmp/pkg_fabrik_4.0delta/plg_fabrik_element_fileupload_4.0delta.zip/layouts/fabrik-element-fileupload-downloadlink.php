<?php
defined('JPATH_BASE') or die;

use Joomla\CMS\Language\Text;
use Joomla\CMS\Filesystem\File;

$d = $displayData;

$class = $d->downloadImg !== '' ? '' : 'class="btn btn-primary button"';
$target = $d->openInBrowser ? ' target="_blank"' : '';
?>

<?php if (!$d->canDownload) :
    $noImg = ($d->noAccessImage === '');
	$aClass = $noImg ? 'class="btn button"' : '';

    if (!empty($d->noAccessURL)) :
        ?>
        <a href="<?php echo $d->noAccessURL; ?>" <?php echo $aClass; ?>>
    <?php
    endif;

    if ($noImg) :
        ?>
		<i class="icon-cancel-circle"></i>&nbsp; <?php echo Text::_('PLG_ELEMENT_FILEUPLOAD_DOWNLOAD_NO_PERMISSION'); ?>
    <?php
    else :
    ?>
        <img src="<?php echo $d->noAccessImage;?>"
            alt="<?php echo Text::_('PLG_ELEMENT_FILEUPLOAD_DOWNLOAD_NO_PERMISSION'); ?>" />
		<?php
	endif;

	if (!empty($d->noAccessURL)) :
        ?>
        </a>
    <?php
    endif;
	else :?>
<a href="<?php echo $d->href;?>" <?php echo $class; ?> <?php echo $target; ?>>
	<?php if ($d->downloadImg !== '') : ?>
		<img src="<?php echo $d->downloadImg;?>" alt="<?php echo $d->title;?>" />
	<?php else :?>
		<?php echo FabrikHelperHTML::icon('icon-download icon-white'); ?>
        <span><?php echo Text::_('PLG_ELEMENT_FILEUPLOAD_DOWNLOAD'); ?></span>
	<?php endif; ?>
</a>
<?php endif; ?>