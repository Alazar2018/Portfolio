/*! Fabrik */

define(["jquery","fab/element"],function(e,n){return window.FbAccess=new Class({Extends:n,initialize:function(e,n){this.setPlugin("fabrikaccess"),this.parent(e,n)}}),window.FbAccess});