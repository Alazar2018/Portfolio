/*! Fabrik */

define(["jquery","fab/element"],function(e,n){return window.FbUsergroup=new Class({Extends:n,initialize:function(e,n){this.setPlugin("fabrikusergroup"),this.parent(e,n)}}),window.FbUsergroup});