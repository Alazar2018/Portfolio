/*! Fabrik */

define(["jquery","fab/element"],function(i,e){return window.FbTimestamp=new Class({Extends:e,initialize:function(i,e){this.setPlugin("fabriktimestamp"),this.parent(i,e)}}),window.FbTimestamp});