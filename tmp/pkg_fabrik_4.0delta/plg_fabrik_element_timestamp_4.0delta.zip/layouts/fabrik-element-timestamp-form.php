<?php

defined('JPATH_BASE') or die;

$d = $displayData;
?>

<input name="<?php echo $d->name; ?>" id="<?php echo $d->id; ?>"
	type="hidden" value="<?php echo $d->value; ?>" />