/*! Fabrik */

define(["jquery","fab/element"],function(n,e){return window.FbInternalId=new Class({Extends:e,initialize:function(n,e){this.setPlugin("fbInternalId"),this.parent(n,e)}}),window.FbInternalId});