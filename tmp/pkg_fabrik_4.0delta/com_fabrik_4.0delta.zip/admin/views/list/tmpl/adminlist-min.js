/*! Fabrik */

define(["jquery","admin/pluginmanager"],function(n,i){return new Class({Extends:i,type:"list",initialize:function(n,i){this.parent(n,i)}})});