/*! Fabrik */

define(["jquery","element/databasejoin/databasejoin"],function(e,n){return window.FbUser=new Class({Extends:n}),window.FbUser});