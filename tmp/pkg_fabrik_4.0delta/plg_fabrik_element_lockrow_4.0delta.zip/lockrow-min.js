/*! Fabrik */

define(["jquery","fab/element"],function(n,i){return window.FbLockrow=new Class({Extends:i,initialize:function(n,i){this.parent(n,i),this.plugin="FbLockrow",this.setOptions(n,i)}}),window.FbLockrow});