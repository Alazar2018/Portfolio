Fabrik for J!4.2
================

This is a test version, not a complete working version of fabrik.

Work is in progress to get it all working.
Test edit @b

Final version:
================

Working in J!4.x & PHP 8.1, does not work on <J!4.

Possible to upgrade from J!3 with fabrik 3.10 installed to J!4.

No sample application and several links removed from home dashboard.

Backend adapted for Atum template, frontend adapted for Cassiopeia template.

Updated for bootstrap 5.

Only real working plugins included.



See the WIKI for the latest installable version (GitHub zips are not installable), testing instructions etc.  
https://github.com/joomlahenk/fabrik/wiki/Tester-Instructions
